'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Layout from '@/components/Layout';
import { useAuthStore } from '@/store/auth';
import api from '@/lib/api';
import { Button, Card } from '@/components/ui';

export default function DiscountApprovalsPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [pendingOverrides, setPendingOverrides] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending');

  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }
    if (user.role !== 'MANAGER' && user.role !== 'OWNER') {
      router.push('/console');
      return;
    }
    loadData();
  }, [user, router, activeTab]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'pending') {
        const response = await api.get('/api/v1/discounts/override/pending');
        setPendingOverrides(response.data);
      } else {
        const response = await api.get('/api/v1/discounts/override/history');
        setHistory(response.data);
      }
    } catch (error: any) {
      console.error('Failed to load discount overrides:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await api.patch(`/api/v1/discounts/override/${id}/approve`);
      await loadData();
      alert('Discount approved. Complete payment from Orders → Complete Order for that sale.');
    } catch (error: any) {
      console.error('Failed to approve override:', error);
      alert(error.response?.data?.error || 'Failed to approve override');
    }
  };

  const handleReject = async (id: string) => {
    const reason = prompt('Enter rejection reason (optional):');
    try {
      await api.patch(`/api/v1/discounts/override/${id}/reject`, {
        rejectionReason: reason || undefined,
      });
      await loadData();
      alert('Discount override rejected');
    } catch (error: any) {
      console.error('Failed to reject override:', error);
      alert(error.response?.data?.error || 'Failed to reject override');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'REJECTED':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="text-center py-12">
          <p className="text-gray-500 dark:text-gray-400">Loading...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold dark:text-white">Discount Approvals</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Review and approve discount override requests</p>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('pending')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'pending'
                  ? 'border-brand-500 text-brand-600 dark:text-brand-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              Pending ({pendingOverrides.length})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'history'
                  ? 'border-brand-500 text-brand-600 dark:text-brand-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              History
            </button>
          </nav>
        </div>

        {/* Pending Overrides */}
        {activeTab === 'pending' && (
          <div className="space-y-4">
            {pendingOverrides.length === 0 ? (
              <Card>
                <div className="p-6 text-center">
                  <p className="text-gray-500 dark:text-gray-400">No pending discount override requests</p>
                </div>
              </Card>
            ) : (
              pendingOverrides.map((override) => {
                const discountPercent = override.sale.subTotal > 0
                  ? (override.overrideDiscount / override.sale.subTotal) * 100
                  : 0;
                const originalPercent = override.sale.subTotal > 0
                  ? (override.originalDiscount / override.sale.subTotal) * 100
                  : 0;

                return (
                  <Card key={override.id}>
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold dark:text-white">Sale #{override.sale.saleNo}</h3>
                          {override.sale.customer && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Customer: {override.sale.customer.name} ({override.sale.customer.phone})
                            </p>
                          )}
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            Requested by: {override.requester.name} ({override.requester.role}) on{' '}
                            {new Date(override.createdAt).toLocaleString()}
                          </p>
                        </div>
                        <span className="px-2 py-1 rounded text-xs font-semibold bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400">
                          PENDING
                        </span>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Subtotal</p>
                          <p className="font-semibold dark:text-white">₹{override.sale.subTotal.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Original Discount</p>
                          <p className="font-semibold dark:text-white">
                            ₹{override.originalDiscount.toFixed(2)} ({originalPercent.toFixed(2)}%)
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Requested Discount</p>
                          <p className="font-semibold text-brand-600 dark:text-brand-400">
                            ₹{override.overrideDiscount.toFixed(2)} ({discountPercent.toFixed(2)}%)
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Difference</p>
                          <p className="font-semibold text-red-600 dark:text-red-400">
                            ₹{(override.overrideDiscount - override.originalDiscount).toFixed(2)}
                          </p>
                        </div>
                      </div>

                      <div className="mb-4">
                        <p className="text-sm font-semibold dark:text-white mb-1">Reason:</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50 p-3 rounded">
                          {override.reason}
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="primary" onClick={() => handleApprove(override.id)}>
                          Approve
                        </Button>
                        <Button variant="danger" onClick={() => handleReject(override.id)}>
                          Reject
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        )}

        {/* History */}
        {activeTab === 'history' && (
          <div className="space-y-4">
            {history.length === 0 ? (
              <Card>
                <div className="p-6 text-center">
                  <p className="text-gray-500 dark:text-gray-400">No discount override history</p>
                </div>
              </Card>
            ) : (
              history.map((override) => {
                const discountPercent = override.sale.subTotal > 0
                  ? (override.overrideDiscount / override.sale.subTotal) * 100
                  : 0;

                return (
                  <Card key={override.id}>
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold dark:text-white">Sale #{override.sale.saleNo}</h3>
                          {override.sale.customer && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Customer: {override.sale.customer.name}
                            </p>
                          )}
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            Requested by: {override.requester.name} on {new Date(override.createdAt).toLocaleString()}
                          </p>
                          {override.approver && (
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {override.status === 'APPROVED' ? 'Approved' : 'Rejected'} by: {override.approver.name} on{' '}
                              {override.approvedAt ? new Date(override.approvedAt).toLocaleString() : ''}
                            </p>
                          )}
                        </div>
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${getStatusColor(override.status)}`}>
                          {override.status}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Subtotal</p>
                          <p className="font-semibold dark:text-white">₹{override.sale.subTotal.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Discount</p>
                          <p className="font-semibold dark:text-white">
                            ₹{override.overrideDiscount.toFixed(2)} ({discountPercent.toFixed(2)}%)
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Reason</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{override.reason}</p>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}

