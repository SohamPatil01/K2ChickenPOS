'use client';

import Layout from '@/components/Layout';
import ReportLayout from '@/components/ReportLayout';
import { MasaleTypeBadge, ReportMasaleSummary } from '@/components/ReportMasaleSummary';
import { useState, useEffect } from 'react';
import { defaultDateRangeLast30Days } from '@/lib/dateRangeParams';
import {
  downloadReportTable,
  formatCurrency,
  formatReportPeriod,
} from '@/lib/reportExport';
import { masaleSplitFromRows } from '@azela-pos/shared';
import api from '@/lib/api';

export default function ProductWiseSalePage() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any[]>([]);
  const defaultRange = defaultDateRangeLast30Days();
  const [startDate, setStartDate] = useState(defaultRange.start);
  const [endDate, setEndDate] = useState(defaultRange.end);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async (start?: string, end?: string) => {
    setLoading(true);
    try {
      const effectiveStartDate = start !== undefined ? start : startDate;
      const effectiveEndDate = end !== undefined ? end : endDate;
      
      console.log('Loading product-wise sale report with dates:', { effectiveStartDate, effectiveEndDate });
      
      const response = await api.get('/api/v1/reports/product-wise-sale', {
        params: { startDate: effectiveStartDate, endDate: effectiveEndDate },
      });
      
      console.log('Product-wise sale data received:', response.data?.length || 0, 'items');
      setData(response.data || []);
    } catch (error: any) {
      console.error('Failed to load data:', error);
      console.error('Error details:', error.response?.data);
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDateChange = (start: string, end: string) => {
    setStartDate(start);
    setEndDate(end);
    // Use the new dates directly instead of state
    loadData(start, end);
  };

  const totalRevenue = data.reduce((sum, item) => sum + item.revenue, 0);
  const masaleSplit = masaleSplitFromRows(
    data.map((item) => ({
      isMasale: item.isMasale,
      revenue: item.revenue,
      qtyKg: item.qtyKg,
      qtyPcs: item.qtyPcs,
      lineCount: item.salesCount,
    }))
  );

  const handleExport = () => {
    downloadReportTable('Product Wise Sale Report', `product-wise-sale-${startDate}-to-${endDate}`, {
      period: formatReportPeriod(startDate, endDate),
      summary: [
        { label: 'Total Products Sold', value: String(data.length) },
        { label: 'Total Revenue', value: formatCurrency(totalRevenue) },
        { label: 'Masale Revenue', value: formatCurrency(masaleSplit.masaleRevenue) },
        { label: 'Masale Qty (PCS)', value: String(masaleSplit.masaleQtyPcs) },
        { label: 'Chicken / Other Revenue', value: formatCurrency(masaleSplit.otherRevenue) },
      ],
      headers: ['Type', 'Product', 'SKU', 'Category', 'Qty (KG)', 'Qty (PCS)', 'Revenue', 'Sales Count'],
      columnAlign: ['left', 'left', 'left', 'left', 'right', 'right', 'right', 'right'],
      rows: data.map((item) => ({
        kind: 'data' as const,
        cells: [
          item.isMasale ? 'Masale' : 'Chicken',
          item.productName,
          item.sku,
          item.category,
          item.qtyKg.toFixed(2),
          item.qtyPcs,
          formatCurrency(item.revenue),
          item.salesCount,
        ],
      })),
    });
  };

  return (
    <Layout>
      <ReportLayout
        title="Product Wise Sale Report"
        dateRange={true}
        onDateRangeChange={handleDateChange}
        exportable={true}
        onExport={handleExport}
      >
        {loading ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">Loading data...</div>
        ) : data.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">No sales data available for the selected period.</div>
        ) : (
          <>
            <div className="mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Total Products Sold</div>
                  <div className="text-2xl font-bold dark:text-white">{data.length}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Total Revenue</div>
                  <div className="text-2xl font-bold dark:text-white">₹{totalRevenue.toFixed(2)}</div>
                </div>
              </div>
              <ReportMasaleSummary
                masaleRevenue={masaleSplit.masaleRevenue}
                masaleQtyPcs={masaleSplit.masaleQtyPcs}
                masaleQtyKg={masaleSplit.masaleQtyKg}
                otherRevenue={masaleSplit.otherRevenue}
              />
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-900/50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Product</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">SKU</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Category</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Qty (KG)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Qty (PCS)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Revenue</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Sales</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {data.map((item, idx) => (
                    <tr key={item.productId} className={`hover:bg-gray-50 dark:hover:bg-gray-700/50 ${item.isMasale ? 'bg-brand-50/20 dark:bg-brand-900/10' : ''}`}>
                      <td className="px-6 py-4 text-sm"><MasaleTypeBadge isMasale={item.isMasale} /></td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">{item.productName}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{item.sku}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{item.category}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{item.qtyKg.toFixed(2)}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{item.qtyPcs}</td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">₹{item.revenue.toFixed(2)}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{item.salesCount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </ReportLayout>
    </Layout>
  );
}

