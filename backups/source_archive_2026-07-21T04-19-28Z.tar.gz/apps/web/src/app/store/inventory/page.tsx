"use client";

import { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/auth";
import { useNotificationStore } from "@/store/notification";
import api from "@/lib/api";
import { compressImageFile } from "@/lib/compressImage";
import { BrandLoader } from "@/components/ui";
import Link from "next/link";

interface StoreStockBreakdown {
  storeId: string;
  storeName: string;
  qtyKg: number;
  qtyPcs: number;
}

interface InventoryItem {
  productId: string;
  productName: string;
  sku: string;
  plu: string;
  unitType: "KG" | "PCS";
  currentQtyKg: number;
  currentQtyPcs: number;
  storeBreakdown?: StoreStockBreakdown[];
  imageUrl?: string | null;
  pricePerUnit?: number;
  categoryName?: string;
  createdAt?: string;
}

/** Masale / spices — sort newest first by product createdAt */
function isMasaleLikeCategory(name: string): boolean {
  const n = (name || "").toLowerCase();
  return n.includes("spice") || n.includes("masale") || n.includes("masala");
}

function pluNumericKey(plu: string): number {
  const digits = String(plu || "").replace(/\D/g, "");
  if (!digits) return Number.NaN;
  const n = parseInt(digits, 10);
  return Number.isFinite(n) ? n : Number.NaN;
}

/** Raw chicken & other catalog: PLU order. Masale block: created date (newest first). */
function sortInventoryForDisplay(items: InventoryItem[]): InventoryItem[] {
  const masale: InventoryItem[] = [];
  const meat: InventoryItem[] = [];
  for (const row of items) {
    if (isMasaleLikeCategory(row.categoryName || "")) masale.push(row);
    else meat.push(row);
  }
  masale.sort((a, b) => {
    const ta = new Date(a.createdAt || 0).getTime();
    const tb = new Date(b.createdAt || 0).getTime();
    return tb - ta;
  });
  meat.sort((a, b) => {
    const na = pluNumericKey(a.plu);
    const nb = pluNumericKey(b.plu);
    if (Number.isFinite(na) && Number.isFinite(nb) && na !== nb) return na - nb;
    return String(a.plu).localeCompare(String(b.plu), undefined, {
      numeric: true,
    });
  });
  return [...meat, ...masale];
}

function formatInventoryDate(iso?: string): string {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return "—";
  }
}

interface Category {
  id: string;
  name: string;
}

interface Product {
  id: string;
  name: string;
  sku: string;
  plu: string;
  unitType: "KG" | "PCS";
  pricePerUnit: number;
  taxRate: number;
  imageUrl?: string | null;
}

export default function StoreInventoryPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const { showNotification } = useNotificationStore();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const displayInventory = useMemo(
    () => sortInventoryForDisplay(inventory),
    [inventory]
  );
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    sku: "",
    plu: "",
    categoryId: "",
    unitType: "KG" as "KG" | "PCS",
    taxRate: "0",
    pricePerUnit: "",
    imageUrl: "",
    imageFile: null as File | null,
  });
  const [editLoading, setEditLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const [showAdjustModal, setShowAdjustModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<InventoryItem | null>(
    null
  );
  const [adjustForm, setAdjustForm] = useState({
    qtyKg: "",
    qtyPcs: "",
    reason: "ADJUSTMENT",
  });

  const [showEditStockModal, setShowEditStockModal] = useState(false);
  const [editStockProduct, setEditStockProduct] =
    useState<InventoryItem | null>(null);
  const [editStockForm, setEditStockForm] = useState({
    qtyKg: "",
    qtyPcs: "",
    reason: "CORRECTION",
  });

  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [addProductLoading, setAddProductLoading] = useState(false);
  const [addProductForm, setAddProductForm] = useState({
    name: "",
    sku: "",
    plu: "",
    categoryId: "",
    unitType: "KG" as "KG" | "PCS",
    taxRate: "0",
    pricePerUnit: "",
    imageUrl: "",
    imageFile: null as File | null,
  });
  const [addProductImagePreview, setAddProductImagePreview] = useState<
    string | null
  >(null);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [productToDelete, setProductToDelete] = useState<InventoryItem | null>(
    null
  );
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Add Stock Tab State
  const [activeTab, setActiveTab] = useState<"inventory" | "addStock">(
    "inventory"
  );
  const [stockItems, setStockItems] = useState<
    Array<{
      productId: string;
      productName: string;
      qtyKg?: number;
      qtyPcs?: number;
      reason: string;
    }>
  >([]);
  const [selectedStockProduct, setSelectedStockProduct] =
    useState<Product | null>(null);
  const [stockItemForm, setStockItemForm] = useState({
    qtyKg: "",
    qtyPcs: "",
    reason: "RECEIVE",
  });
  const [stockProducts, setStockProducts] = useState<Product[]>([]);
  const [addingStock, setAddingStock] = useState(false);

  /** HQ owner: franchise sites for choosing which store receives ledger adjustments */
  const [ownerFranchises, setOwnerFranchises] = useState<
    { id: string; name: string }[]
  >([]);
  const [ownerOpsLedgerStoreId, setOwnerOpsLedgerStoreId] = useState("");

  const showOwnerLedgerPicker =
    user?.store?.type === "OWNER" && ownerFranchises.length > 0;

  const appendLedgerStoreToAdjustBody = (requestData: Record<string, unknown>) => {
    if (
      showOwnerLedgerPicker &&
      (ownerOpsLedgerStoreId || user?.storeId)
    ) {
      requestData.ledgerStoreId = ownerOpsLedgerStoreId || user!.storeId;
    }
  };

  // Refs to prevent multiple simultaneous loads
  const loadingRef = useRef(false);
  const lastLoadTimeRef = useRef(0);
  const loadInventoryRef = useRef<((force?: boolean) => Promise<void>) | null>(
    null
  );
  const createProductInFlightRef = useRef(false);

  const loadInventory = useCallback(
    async (force = false) => {
      // Prevent multiple simultaneous loads
      const now = Date.now();
      if (loadingRef.current && !force) {
        return;
      }

      // Debounce: don't load if last load was less than 1 second ago (unless forced)
      if (!force && now - lastLoadTimeRef.current < 1000) {
        return;
      }

      loadingRef.current = true;
      lastLoadTimeRef.current = now;
      setLoading(true);

      try {
        const timestamp = Date.now();
        const params: Record<string, string | number> = { _t: timestamp };
        if (user?.storeId) {
          params.storeId = user.storeId;
        }

        const response = await api.get("/api/v1/inventory/summary", {
          params,
          headers: {
            "Cache-Control": "no-cache, no-store, must-revalidate",
            Pragma: "no-cache",
            Expires: "0",
          },
        });

        if (!response.data || !Array.isArray(response.data)) {
          setInventory([]);
          return;
        }

        const inventoryData = response.data as InventoryItem[];
        setInventory(inventoryData);

        if (force && inventoryData.length > 0) {
          showNotification(
            `Loaded ${inventoryData.length} inventory items`,
            "success"
          );
        }
      } catch (error: any) {
        console.error("Failed to load inventory:", error);
        console.error("Error details:", error.response?.data);
        // Always set to empty on error
        setInventory([]);
        const errorMessage =
          error.response?.data?.error ||
          error.message ||
          "Failed to load inventory";
        showNotification(`Error loading inventory: ${errorMessage}`, "error");
      } finally {
        setLoading(false);
        loadingRef.current = false;
      }
    },
    [user, showNotification]
  );

  // Store loadInventory in ref so it can be used in useEffect without dependency issues
  loadInventoryRef.current = loadInventory;

  useEffect(() => {
    if (user?.storeId) {
      setOwnerOpsLedgerStoreId(user.storeId);
    }
  }, [user?.storeId]);

  useEffect(() => {
    if (user?.store?.type !== "OWNER") {
      setOwnerFranchises([]);
      return;
    }
    let cancelled = false;
    api
      .get("/api/v1/stores/franchises")
      .then((r) => {
        if (cancelled) return;
        const raw = r.data;
        const list = Array.isArray(raw)
          ? raw.map((f: { id: string; name: string }) => ({
              id: f.id,
              name: f.name,
            }))
          : [];
        setOwnerFranchises(list);
      })
      .catch(() => {
        if (!cancelled) setOwnerFranchises([]);
      });
    return () => {
      cancelled = true;
    };
  }, [user?.store?.type]);

  useEffect(() => {
    if (user === undefined) return;

    if (!user) {
      router.push("/login");
      return;
    }

    if (
      user.role !== "MANAGER" &&
      user.role !== "OWNER" &&
      user.role !== "CASHIER"
    ) {
      router.push("/store");
      return;
    }

    if (
      user &&
      (user.role === "MANAGER" ||
        user.role === "OWNER" ||
        user.role === "CASHIER")
    ) {
      loadInventoryRef.current?.(true); // Force initial load
      loadCategories();
      if (activeTab === "addStock") {
        loadStockProducts();
      }
    }

    // Listen for PO finalization events to refresh inventory
    const handlePOFinalized = () => {
      loadInventoryRef.current?.(true);
    };

    window.addEventListener("po-finalized", handlePOFinalized);

    return () => {
      window.removeEventListener("po-finalized", handlePOFinalized);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, router, activeTab]);

  const loadCategories = async () => {
    try {
      const response = await api.get("/api/v1/products/categories", {
        params: { _t: Date.now() },
        headers: { "Cache-Control": "no-cache", Pragma: "no-cache" },
      });
      if (Array.isArray(response.data)) {
        setCategories(response.data);
      } else {
        setCategories([]);
      }
    } catch (error) {
      console.error("Failed to load categories", error);
      setCategories([]);
    }
  };

  const loadStockProducts = async () => {
    try {
      const response = await api.get("/api/v1/products", {
        params: { _t: Date.now() },
        headers: { "Cache-Control": "no-cache", Pragma: "no-cache" },
      });
      setStockProducts(response.data || []);
    } catch (error) {
      console.error("Failed to load products", error);
      setStockProducts([]);
    }
  };

  const handleAddStockItem = () => {
    if (!selectedStockProduct) {
      showNotification("Please select a product", "error");
      return;
    }

    const qtyKg = parseFloat(stockItemForm.qtyKg) || 0;
    const qtyPcs = parseFloat(stockItemForm.qtyPcs) || 0;

    if (selectedStockProduct.unitType === "KG" && qtyKg <= 0) {
      showNotification("Please enter quantity", "error");
      return;
    }
    if (selectedStockProduct.unitType === "PCS" && qtyPcs <= 0) {
      showNotification("Please enter quantity", "error");
      return;
    }

    setStockItems([
      ...stockItems,
      {
        productId: selectedStockProduct.id,
        productName: selectedStockProduct.name,
        qtyKg: selectedStockProduct.unitType === "KG" ? qtyKg : undefined,
        qtyPcs: selectedStockProduct.unitType === "PCS" ? qtyPcs : undefined,
        reason: stockItemForm.reason,
      },
    ]);

    setSelectedStockProduct(null);
    setStockItemForm({ qtyKg: "", qtyPcs: "", reason: "RECEIVE" });
  };

  const handleRemoveStockItem = (index: number) => {
    setStockItems(stockItems.filter((_, i) => i !== index));
  };

  const handleAddStock = async () => {
    if (stockItems.length === 0) {
      showNotification("Please add at least one item", "error");
      return;
    }

    setAddingStock(true);
    try {
      // Add each item to inventory
      for (const item of stockItems) {
        const requestData: any = {
          productId: item.productId,
          reason: item.reason,
        };

        // Only include the quantity field that is provided
        if (item.qtyKg !== undefined && item.qtyKg !== null) {
          requestData.qtyKg = item.qtyKg;
        }
        if (item.qtyPcs !== undefined && item.qtyPcs !== null) {
          // Ensure qtyPcs is an integer
          requestData.qtyPcs = Math.round(item.qtyPcs);
        }

        appendLedgerStoreToAdjustBody(requestData);
        await api.post("/api/v1/inventory/adjust", requestData);
      }

      showNotification(
        `Successfully added ${stockItems.length} item(s) to inventory!`,
        "success"
      );
      setStockItems([]);
      setSelectedStockProduct(null);
      setStockItemForm({ qtyKg: "", qtyPcs: "", reason: "RECEIVE" });
      // Wait for DB commit then refresh inventory and product lists so Egg/others show updated counts
      await new Promise((resolve) => setTimeout(resolve, 500));
      await loadInventory(true);
      await loadStockProducts();
      await loadCategories();
      setActiveTab("inventory"); // Switch back to inventory tab
    } catch (error: any) {
      console.error("Failed to add stock:", error);
      showNotification(
        error.response?.data?.error || "Failed to add stock",
        "error"
      );
    } finally {
      setAddingStock(false);
    }
  };

  const generateNextSKUAndPLU = async () => {
    try {
      const response = await api.get("/api/v1/products");
      const products = response.data || [];

      const skuNumbers: number[] = [];
      const pluNumbers: number[] = [];

      products.forEach((p: any) => {
        const skuMatch = p.sku.match(/\d+/);
        if (skuMatch) {
          skuNumbers.push(parseInt(skuMatch[0], 10));
        }

        const pluMatch = p.plu.match(/\d+/);
        if (pluMatch) {
          pluNumbers.push(parseInt(pluMatch[0], 10));
        }
      });

      const nextSkuNum =
        skuNumbers.length > 0 ? Math.max(...skuNumbers) + 1 : 1;
      const nextPluNum =
        pluNumbers.length > 0 ? Math.max(...pluNumbers) + 1 : 1;

      const nextSKU = String(nextSkuNum).padStart(5, "0");
      const nextPLU = String(nextPluNum).padStart(5, "0");

      return { sku: nextSKU, plu: nextPLU };
    } catch (error) {
      console.error("Failed to generate SKU/PLU:", error);
      return { sku: "00001", plu: "00001" };
    }
  };

  const handleAdjust = async () => {
    if (!selectedProduct) return;

    // Parse values but preserve exact precision
    const qtyKgStr = adjustForm.qtyKg.trim();
    const qtyPcsStr = adjustForm.qtyPcs.trim();
    const qtyKg = qtyKgStr ? parseFloat(qtyKgStr) : 0;
    const qtyPcs = qtyPcsStr ? parseFloat(qtyPcsStr) : 0;

    // If both are zero or empty, show error
    if ((!qtyKg || qtyKg === 0) && (!qtyPcs || qtyPcs === 0)) {
      showNotification("Please enter a quantity", "error");
      return;
    }

    if (selectedProduct.unitType === "KG" && qtyKg === 0) {
      showNotification("Please enter quantity", "error");
      return;
    }
    if (selectedProduct.unitType === "PCS" && qtyPcs === 0) {
      showNotification("Please enter quantity", "error");
      return;
    }

    try {
      const requestData: any = {
        productId: selectedProduct.productId,
        reason: adjustForm.reason || "ADJUSTMENT",
      };

      // Only include the quantity field that matches the unit type
      // Send the exact parsed value - don't round qtyKg to preserve precision
      if (selectedProduct.unitType === "KG") {
        requestData.qtyKg = qtyKg; // Send exact value, no rounding
      } else {
        // Ensure qtyPcs is an integer
        requestData.qtyPcs = Math.round(qtyPcs);
      }

      appendLedgerStoreToAdjustBody(requestData);
      const response = await api.post("/api/v1/inventory/adjust", requestData);

      if (response.data) {
        showNotification("Inventory adjusted successfully!", "success");
        await new Promise((resolve) => setTimeout(resolve, 500));
        await loadInventory(true);
        await loadStockProducts();
        await loadCategories();
        setShowAdjustModal(false);
        setSelectedProduct(null);
        setAdjustForm({ qtyKg: "", qtyPcs: "", reason: "ADJUSTMENT" });
      }
    } catch (error: any) {
      console.error("Inventory adjustment error:", error);
      const errorMessage =
        error.response?.data?.error ||
        error.response?.data?.details ||
        error.message ||
        "Failed to adjust inventory";
      showNotification(errorMessage, "error");
    }
  };

  const openAdjustModal = (item: InventoryItem) => {
    setSelectedProduct(item);
    setAdjustForm({
      qtyKg: "",
      qtyPcs: "",
      reason: "ADJUSTMENT",
    });
    setShowAdjustModal(true);
  };

  const openEditStockModal = (item: InventoryItem) => {
    setEditStockProduct(item);
    setEditStockForm({
      qtyKg: item.unitType === "KG" ? item.currentQtyKg.toFixed(2) : "",
      qtyPcs: item.unitType === "PCS" ? item.currentQtyPcs.toString() : "",
      reason: "CORRECTION",
    });
    setShowEditStockModal(true);
  };

  const handleEditStock = async () => {
    if (!editStockProduct) return;

    const newQtyKg = parseFloat(editStockForm.qtyKg) || 0;
    const newQtyPcs = parseFloat(editStockForm.qtyPcs) || 0;

    if (editStockProduct.unitType === "KG" && editStockForm.qtyKg === "") {
      showNotification("Please enter quantity", "error");
      return;
    }
    if (editStockProduct.unitType === "PCS" && editStockForm.qtyPcs === "") {
      showNotification("Please enter quantity", "error");
      return;
    }

    try {
      // Calculate the difference needed
      const currentQty =
        editStockProduct.unitType === "KG"
          ? editStockProduct.currentQtyKg
          : editStockProduct.currentQtyPcs;
      const newQty = editStockProduct.unitType === "KG" ? newQtyKg : newQtyPcs;
      const adjustment = newQty - currentQty;

      if (adjustment === 0) {
        showNotification("Stock is already at this value", "info");
        setShowEditStockModal(false);
        return;
      }

      // Use the adjust API with the calculated difference
      const requestData: any = {
        productId: editStockProduct.productId,
        reason: editStockForm.reason || "CORRECTION",
      };

      // Only include the quantity field that matches the unit type
      if (editStockProduct.unitType === "KG") {
        requestData.qtyKg = adjustment;
      } else {
        // Ensure qtyPcs is an integer
        requestData.qtyPcs = Math.round(adjustment);
      }

      appendLedgerStoreToAdjustBody(requestData);
      const response = await api.post("/api/v1/inventory/adjust", requestData);

      if (response.data) {
        showNotification("Stock updated successfully!", "success");
        await new Promise((resolve) => setTimeout(resolve, 500));
        await loadInventory(true);
        await loadStockProducts();
        await loadCategories();
        setShowEditStockModal(false);
        setEditStockProduct(null);
        setEditStockForm({
          qtyKg: "",
          qtyPcs: "",
          reason: "CORRECTION",
        });
      }
    } catch (error: any) {
      console.error("[Frontend] Edit stock error:", error);
      console.error("[Frontend] Error response:", error.response);
      console.error("[Frontend] Error response data:", error.response?.data);
      const errorMessage =
        error.response?.data?.error ||
        error.response?.data?.details ||
        error.message ||
        "Failed to update stock";
      showNotification(errorMessage, "error");
    }
  };

  const openDeleteModal = (item: InventoryItem) => {
    setProductToDelete(item);
    setShowDeleteModal(true);
  };

  const handleDeleteProduct = async () => {
    if (!productToDelete) return;

    setDeleteLoading(true);
    try {
      const response = await api.delete(
        `/api/v1/products/${productToDelete.productId}`
      );

      if (
        response.status === 200 ||
        response.status === 204 ||
        response.data?.success
      ) {
        await loadInventory();
        setShowDeleteModal(false);
        setProductToDelete(null);
        showNotification("Product removed from catalog", "success");
      } else {
        throw new Error("Delete operation did not succeed");
      }
    } catch (error: any) {
      console.error("Failed to delete product:", error);
      const message =
        error?.response?.data?.error ||
        error?.response?.data?.details ||
        error?.response?.data?.message ||
        error.message ||
        "Failed to delete product";
      showNotification(message, "error");
    } finally {
      setDeleteLoading(false);
    }
  };

  const resetAddProductForm = () => {
    setAddProductForm({
      name: "",
      sku: "",
      plu: "",
      categoryId: "",
      unitType: "KG",
      taxRate: "0",
      pricePerUnit: "",
      imageUrl: "",
      imageFile: null,
    });
    setAddProductImagePreview(null);
  };

  const handleAddProductImageFileChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        alert("Please select an image file");
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        alert("Image size should be less than 5MB");
        return;
      }

      setAddProductForm({ ...addProductForm, imageFile: file, imageUrl: "" });

      const reader = new FileReader();
      reader.onloadend = () => {
        setAddProductImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const openAddProductModal = async () => {
    const { sku, plu } = await generateNextSKUAndPLU();
    setAddProductForm({
      ...addProductForm,
      sku,
      plu,
    });
    setShowAddProductModal(true);
  };

  const handleCreateProduct = async () => {
    if (createProductInFlightRef.current || addProductLoading) return;

    if (!addProductForm.name) {
      showNotification("Please fill in product name", "warning");
      return;
    }
    if (!addProductForm.sku || !addProductForm.plu) {
      showNotification("SKU and PLU are required", "warning");
      return;
    }
    if (!addProductForm.categoryId) {
      showNotification("Please select a category", "warning");
      return;
    }
    if (!addProductForm.pricePerUnit) {
      showNotification("Please enter a price", "warning");
      return;
    }

    createProductInFlightRef.current = true;
    setAddProductLoading(true);
    try {
      const taxRate = parseFloat(addProductForm.taxRate || "0") || 0;
      const pricePerUnit = parseFloat(addProductForm.pricePerUnit);

      let imageUrl = addProductForm.imageUrl;
      if (addProductForm.imageFile) {
        imageUrl = await compressImageFile(addProductForm.imageFile);
      }

      const createRes = await api.post("/api/v1/products", {
        sku: addProductForm.sku,
        plu: addProductForm.plu,
        name: addProductForm.name,
        categoryId: addProductForm.categoryId,
        unitType: addProductForm.unitType,
        taxRate,
        imageUrl: imageUrl || undefined,
      });

      const productId = createRes.data?.id;
      if (!productId) {
        throw new Error("Product created but no ID returned");
      }

      await api.post(`/api/v1/products/${productId}/price`, {
        pricePerUnit,
      });

      await loadInventory();

      resetAddProductForm();
      setShowAddProductModal(false);
      showNotification(
        "Product created. Use Adjust to add opening stock if needed.",
        "success"
      );
    } catch (error: any) {
      console.error("Failed to create product:", error);
      const message =
        error?.response?.data?.error ||
        error.message ||
        "Failed to create product";
      showNotification(message, "error");
    } finally {
      createProductInFlightRef.current = false;
      setAddProductLoading(false);
    }
  };

  const openEditModal = async (item: InventoryItem) => {
    try {
      const response = await api.get(`/api/v1/products/${item.productId}`);
      const product = response.data;

      setEditingProduct(product);
      setEditForm({
        name: product.name || "",
        sku: product.sku || "",
        plu: product.plu || "",
        categoryId: product.categoryId || "",
        unitType: product.unitType || "KG",
        taxRate: product.taxRate?.toString() || "0",
        pricePerUnit: product.pricePerUnit?.toString() || "",
        imageUrl: product.imageUrl || "",
        imageFile: null,
      });
      setImagePreview(product.imageUrl || null);
      setShowEditModal(true);
    } catch (error: any) {
      console.error("Failed to load product details:", error);
      alert("Failed to load product details");
    }
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) {
        alert("Please select an image file");
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        alert("Image size should be less than 5MB");
        return;
      }

      setEditForm({ ...editForm, imageFile: file });

      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdateProduct = async () => {
    if (!editingProduct) return;

    if (!editForm.name || !editForm.sku || !editForm.plu) {
      alert("Please fill in Name, SKU and PLU");
      return;
    }
    if (!editForm.categoryId) {
      alert("Please select a category");
      return;
    }
    if (!editForm.pricePerUnit) {
      alert("Please enter a price");
      return;
    }

    setEditLoading(true);
    try {
      let imageUrl = editForm.imageUrl;

      if (editForm.imageFile) {
        imageUrl = await compressImageFile(editForm.imageFile);
      }

      await api.put(`/api/v1/products/${editingProduct.id}`, {
        name: editForm.name,
        sku: editForm.sku,
        plu: editForm.plu,
        categoryId: editForm.categoryId,
        unitType: editForm.unitType,
        taxRate: parseFloat(editForm.taxRate || "0") || 0,
        imageUrl: imageUrl || null,
      });

      const currentPrice = editingProduct.pricePerUnit || 0;
      const newPrice = parseFloat(editForm.pricePerUnit);
      if (currentPrice !== newPrice) {
        await api.post(`/api/v1/products/${editingProduct.id}/price`, {
          pricePerUnit: newPrice,
        });
      }

      await loadInventory(true);
      await loadStockProducts();
      await loadCategories();

      setShowEditModal(false);
      setEditingProduct(null);
      setEditForm({
        name: "",
        sku: "",
        plu: "",
        categoryId: "",
        unitType: "KG",
        taxRate: "0",
        pricePerUnit: "",
        imageUrl: "",
        imageFile: null,
      });
      setImagePreview(null);
      alert("Product updated successfully!");
    } catch (error: any) {
      console.error("Failed to update product:", error);
      const message =
        error?.response?.data?.error ||
        error.message ||
        "Failed to update product";
      alert(message);
    } finally {
      setEditLoading(false);
    }
  };

  if (loading && inventory.length === 0) {
    return (
      <div className="flex justify-center py-16">
        <BrandLoader label="Loading inventory…" />
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto h-full min-h-0 flex flex-col">
      {/* Header Section - Stacked on mobile */}
      <div className="flex flex-col gap-3 sm:gap-4 mb-3 sm:mb-4 flex-shrink-0">
        <div>
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-ink mb-1 sm:mb-2">
                Inventory
              </h1>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
                {activeTab === "inventory"
                  ? 'Click "Adjust" on any product to add or subtract inventory'
                  : "Add multiple items to inventory at once"}
              </p>
              {showOwnerLedgerPicker && activeTab === "inventory" && (
                <p className="text-xs text-amber-700 dark:text-amber-300 mt-2 max-w-xl">
                  Stock totals combine HQ and all franchise locations. When you
                  adjust, pick which site should receive the change so counts stay
                  correct.
                </p>
              )}
            </div>
            <button
              onClick={() => loadInventory(true)}
              disabled={loading}
              className="px-4 py-2 bg-gradient-brand text-white rounded-xl shadow-glow-brand hover:shadow-glow-brand-lg hover:brightness-105 disabled:opacity-60 disabled:shadow-none flex items-center gap-2 text-sm transition-all"
              title="Refresh inventory"
            >
              <span>🔄</span>
              <span>{loading ? "Refreshing..." : "Refresh"}</span>
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-surface-2/60 w-fit">
          <button
            onClick={() => setActiveTab("inventory")}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === "inventory"
                ? "bg-surface shadow-card border border-brand-500/20 text-brand-600 dark:text-brand-400"
                : "text-ink-secondary hover:text-ink"
            }`}
          >
            Inventory List
          </button>
          <button
            onClick={() => {
              setActiveTab("addStock");
              if (stockProducts.length === 0) {
                loadStockProducts();
              }
            }}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === "addStock"
                ? "bg-surface shadow-card border border-brand-500/20 text-brand-600 dark:text-brand-400"
                : "text-ink-secondary hover:text-ink"
            }`}
          >
            Add Stock
          </button>
        </div>

        {/* Action Buttons - Stacked on mobile, row on desktop */}
        {activeTab === "inventory" && (
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 w-full sm:w-auto">
            <button
              onClick={openAddProductModal}
              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 bg-brand-500 text-white rounded-md hover:bg-brand-600 text-sm sm:text-base transition-colors touch-target font-medium"
            >
              Add Product
            </button>
            <button
              onClick={() => loadInventory(true)}
              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 bg-gray-500 dark:bg-gray-600 text-white rounded-md hover:bg-gray-600 dark:hover:bg-gray-700 text-sm sm:text-base transition-colors touch-target font-medium"
            >
              Refresh
            </button>
            <Link
              href="/store/stock-ledger"
              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 bg-brand-500 text-white rounded-md hover:bg-brand-600 text-sm sm:text-base transition-colors text-center touch-target font-medium"
            >
              Stock Ledger
            </Link>
          </div>
        )}
      </div>

      {/* Content based on active tab */}
      {activeTab === "inventory" ? (
        /* Table Container - Responsive with horizontal scroll on mobile and vertical scroll on iPad */
        <div className="flex-1 min-h-0 flex flex-col glass-panel-strong rounded-2xl overflow-hidden animate-fade-in">
          <p className="text-xs text-gray-500 dark:text-gray-400 px-3 sm:px-4 py-2 border-b border-gray-100 dark:border-gray-700">
            Order: meat / raw chicken by PLU, then masale &amp; spices by date added (newest first).
          </p>
          <div className="flex-1 overflow-y-auto overflow-x-auto -mx-3 sm:mx-0 min-h-0">
            <div className="inline-block min-w-full align-middle">
              <table className="table-glass min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-surface-2/80 sticky top-0 z-10 backdrop-blur-sm">
                  <tr>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                      Image
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                      Product
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase hidden lg:table-cell">
                      Category
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase hidden sm:table-cell">
                      SKU
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase hidden md:table-cell">
                      PLU
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase hidden lg:table-cell">
                      Added
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                      Unit
                    </th>
                    <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                      Stock
                    </th>
                    <th className="px-2 sm:px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase min-w-[150px]">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {loading ? (
                    <tr>
                      <td colSpan={9} className="px-6 py-4 text-center">
                        <p className="text-gray-500 dark:text-gray-400">
                          Loading...
                        </p>
                      </td>
                    </tr>
                  ) : inventory.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-6 py-4 text-center">
                        <div className="py-8">
                          <p className="text-gray-500 dark:text-gray-400 mb-2">
                            No inventory data found
                          </p>
                          <p className="text-sm text-gray-400 dark:text-gray-500 mb-4">
                            Products may not have inventory entries yet.
                          </p>
                          <button
                            onClick={openAddProductModal}
                            className="px-4 py-2 bg-brand-500 text-white rounded-md hover:bg-brand-600"
                          >
                            Add First Product
                          </button>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    displayInventory.map((item) => (
                      <tr
                        key={item.productId}
                        className="hover:bg-brand-100/30 dark:hover:bg-brand-900/10 transition-colors"
                      >
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt={item.productName}
                              className="w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 object-cover rounded"
                              onError={(e) => {
                                (e.target as HTMLImageElement).style.display =
                                  "none";
                              }}
                            />
                          ) : (
                            <div className="w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center text-gray-400 dark:text-gray-500 text-xs">
                              No Image
                            </div>
                          )}
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 font-medium min-w-[120px]">
                          <div className="text-sm sm:text-base lg:text-lg dark:text-white font-semibold">
                            {item.productName}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 sm:hidden mt-1">
                            SKU: {item.sku} | PLU: {item.plu}
                          </div>
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 hidden lg:table-cell max-w-[140px] truncate">
                          {item.categoryName || "—"}
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap text-sm sm:text-base text-gray-500 dark:text-gray-400 hidden sm:table-cell">
                          {item.sku}
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap text-sm sm:text-base text-gray-500 dark:text-gray-400 hidden md:table-cell">
                          {item.plu}
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500 dark:text-gray-400 hidden lg:table-cell">
                          {formatInventoryDate(item.createdAt)}
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap text-sm sm:text-base text-gray-500 dark:text-gray-400">
                          <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs sm:text-sm font-medium">
                            {item.unitType}
                          </span>
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 whitespace-nowrap">
                          {item.unitType === "KG" ? (
                            <span
                              className={`font-semibold text-sm sm:text-base lg:text-lg ${
                                item.currentQtyKg < 0
                                  ? "text-red-600 dark:text-red-400"
                                  : item.currentQtyKg === 0
                                  ? "text-yellow-600 dark:text-yellow-400"
                                  : "text-gray-900 dark:text-white"
                              }`}
                            >
                              {item.currentQtyKg.toFixed(2)} kg
                            </span>
                          ) : (
                            <span
                              className={`font-semibold text-sm sm:text-base lg:text-lg ${
                                item.currentQtyPcs < 0
                                  ? "text-red-600 dark:text-red-400"
                                  : item.currentQtyPcs === 0
                                  ? "text-yellow-600 dark:text-yellow-400"
                                  : "text-gray-900 dark:text-white"
                              }`}
                            >
                              {item.currentQtyPcs} pcs
                            </span>
                          )}
                          {item.storeBreakdown &&
                            item.storeBreakdown.length > 1 && (
                              <div className="mt-1.5 flex flex-col gap-0.5">
                                {item.storeBreakdown.map((b) => (
                                  <span
                                    key={b.storeId}
                                    className="text-[10px] sm:text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap"
                                    title={`Stock at ${b.storeName}`}
                                  >
                                    {b.storeName}:{" "}
                                    {item.unitType === "KG"
                                      ? `${b.qtyKg.toFixed(2)} kg`
                                      : `${b.qtyPcs} pcs`}
                                  </span>
                                ))}
                              </div>
                            )}
                        </td>
                        <td className="px-2 sm:px-4 lg:px-6 py-3 sm:py-4 text-sm min-w-[140px] sm:min-w-[180px]">
                          <div className="flex flex-col gap-1.5 sm:gap-2">
                            <div className="flex gap-1.5 sm:gap-2">
                              <button
                                type="button"
                                onClick={() => openEditModal(item)}
                                className="flex-1 sm:flex-none px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-medium bg-brand-500 text-white rounded hover:bg-brand-600 active:bg-brand-700 transition-colors touch-target whitespace-nowrap"
                              >
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() => openAdjustModal(item)}
                                className="flex-1 sm:flex-none px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-medium bg-orange-500 text-white rounded hover:bg-orange-600 active:bg-orange-700 transition-colors touch-target whitespace-nowrap"
                              >
                                Adjust
                              </button>
                            </div>
                            <div className="flex gap-1.5 sm:gap-2">
                              <button
                                type="button"
                                onClick={() => openEditStockModal(item)}
                                className="flex-1 px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-medium bg-blue-500 text-white rounded hover:bg-blue-600 active:bg-blue-700 transition-colors touch-target whitespace-nowrap"
                              >
                                Edit Stock
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  openDeleteModal(item);
                                }}
                                className="flex-1 px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold bg-red-500 text-white rounded hover:bg-red-600 active:bg-red-700 transition-colors touch-target whitespace-nowrap"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Add Stock Tab */
        <div className="flex-1 min-h-0 flex flex-col glass-panel-strong rounded-2xl overflow-hidden animate-fade-in">
          <div className="flex-1 overflow-y-auto p-4 sm:p-6">
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Add Item Form */}
              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 sm:p-6">
                <h2 className="text-lg font-semibold dark:text-white mb-4">
                  Add Stock Item
                </h2>
                {showOwnerLedgerPicker && user?.storeId && (
                  <div className="mb-4 max-w-md">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Receive into store
                    </label>
                    <select
                      value={ownerOpsLedgerStoreId || user.storeId}
                      onChange={(e) =>
                        setOwnerOpsLedgerStoreId(e.target.value)
                      }
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                    >
                      <option value={user.storeId}>
                        {user.store.name} (HQ)
                      </option>
                      {ownerFranchises.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Product *
                    </label>
                    <select
                      value={selectedStockProduct?.id || ""}
                      onChange={(e) => {
                        const product = stockProducts.find(
                          (p) => p.id === e.target.value
                        );
                        setSelectedStockProduct(product || null);
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                    >
                      <option value="">Select product</option>
                      {stockProducts.map((product) => (
                        <option key={product.id} value={product.id}>
                          {product.name} ({product.sku})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Quantity{" "}
                      {selectedStockProduct?.unitType === "KG"
                        ? "(kg)"
                        : "(pcs)"}{" "}
                      *
                    </label>
                    <input
                      type="number"
                      value={
                        selectedStockProduct?.unitType === "KG"
                          ? stockItemForm.qtyKg
                          : stockItemForm.qtyPcs
                      }
                      onChange={(e) => {
                        if (selectedStockProduct?.unitType === "KG") {
                          setStockItemForm({
                            ...stockItemForm,
                            qtyKg: e.target.value,
                          });
                        } else {
                          setStockItemForm({
                            ...stockItemForm,
                            qtyPcs: e.target.value,
                          });
                        }
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                      placeholder="0"
                      step={
                        selectedStockProduct?.unitType === "KG" ? "0.01" : "1"
                      }
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Reason
                    </label>
                    <select
                      value={stockItemForm.reason}
                      onChange={(e) =>
                        setStockItemForm({
                          ...stockItemForm,
                          reason: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                    >
                      <option value="RECEIVE">Receive</option>
                      <option value="ADJUSTMENT">Adjustment</option>
                      <option value="CORRECTION">Correction</option>
                      <option value="OPENING">Opening Stock</option>
                      <option value="RETURN">Return</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                </div>
                <button
                  onClick={handleAddStockItem}
                  className="mt-4 px-4 py-2 bg-brand-500 text-white rounded-md hover:bg-brand-600 transition-colors"
                >
                  Add to List
                </button>
              </div>

              {/* Stock Items List */}
              {stockItems.length > 0 && (
                <div className="glass-panel-strong rounded-2xl overflow-hidden">
                  <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-semibold dark:text-white">
                      Items to Add ({stockItems.length})
                    </h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="table-glass min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                      <thead className="bg-surface-2/80 sticky top-0 z-10 backdrop-blur-sm">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                            Product
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                            Quantity
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                            Reason
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {stockItems.map((item, index) => (
                          <tr
                            key={index}
                            className="hover:bg-brand-100/30 dark:hover:bg-brand-900/10 transition-colors"
                          >
                            <td className="px-4 py-3 text-sm font-medium dark:text-white">
                              {item.productName}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-300">
                              {item.qtyKg
                                ? `${item.qtyKg} kg`
                                : `${item.qtyPcs} pcs`}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-300">
                              {item.reason}
                            </td>
                            <td className="px-4 py-3 text-sm">
                              <button
                                onClick={() => handleRemoveStockItem(index)}
                                className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                              >
                                Remove
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="p-4 border-t border-gray-200 dark:border-gray-700 flex justify-end gap-3">
                    <button
                      onClick={() => {
                        setStockItems([]);
                        setSelectedStockProduct(null);
                        setStockItemForm({
                          qtyKg: "",
                          qtyPcs: "",
                          reason: "RECEIVE",
                        });
                      }}
                      className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white transition-colors"
                    >
                      Clear All
                    </button>
                    <button
                      onClick={handleAddStock}
                      disabled={addingStock || stockItems.length === 0}
                      className="px-6 py-2 bg-brand-500 text-white rounded-md hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
                    >
                      {addingStock
                        ? "Adding Stock..."
                        : `Add ${stockItems.length} Item(s) to Inventory`}
                    </button>
                  </div>
                </div>
              )}

              {stockItems.length === 0 && (
                <div className="text-center py-12 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <p className="text-gray-500 dark:text-gray-400">
                    No items added yet. Select a product and quantity above to
                    get started.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Adjust Inventory Modal */}
      {showAdjustModal && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-panel-strong rounded-2xl p-4 sm:p-6 w-full max-w-md max-h-[90vh] overflow-y-auto animate-scale-in">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 dark:text-white">
              Adjust Inventory
            </h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                  Product:{" "}
                  <strong className="dark:text-white">
                    {selectedProduct.productName}
                  </strong>
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  Current Stock:{" "}
                  {selectedProduct.unitType === "KG"
                    ? `${selectedProduct.currentQtyKg.toFixed(2)} kg`
                    : `${selectedProduct.currentQtyPcs} pcs`}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {selectedProduct.unitType === "KG"
                    ? "Quantity (kg)"
                    : "Quantity (pcs)"}{" "}
                  *
                </label>
                <input
                  type="number"
                  value={
                    selectedProduct.unitType === "KG"
                      ? adjustForm.qtyKg
                      : adjustForm.qtyPcs
                  }
                  onChange={(e) => {
                    if (selectedProduct.unitType === "KG") {
                      setAdjustForm({ ...adjustForm, qtyKg: e.target.value });
                    } else {
                      setAdjustForm({ ...adjustForm, qtyPcs: e.target.value });
                    }
                  }}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder={selectedProduct.unitType === "KG" ? "0.00" : "0"}
                  step={selectedProduct.unitType === "KG" ? "0.01" : "1"}
                  required
                  autoFocus
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Enter positive value to add, negative to subtract
                </p>
                {showOwnerLedgerPicker && user?.storeId && (
                  <div className="mt-3">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Apply to store
                    </label>
                    <select
                      value={ownerOpsLedgerStoreId || user.storeId}
                      onChange={(e) =>
                        setOwnerOpsLedgerStoreId(e.target.value)
                      }
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                    >
                      <option value={user.storeId}>
                        {user.store.name} (HQ)
                      </option>
                      {ownerFranchises.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
                <div className="mt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const current =
                        selectedProduct.unitType === "KG"
                          ? parseFloat(adjustForm.qtyKg) || 0
                          : parseFloat(adjustForm.qtyPcs) || 0;
                      const add = selectedProduct.unitType === "KG" ? 1 : 10;
                      if (selectedProduct.unitType === "KG") {
                        setAdjustForm({
                          ...adjustForm,
                          qtyKg: (current + add).toString(),
                        });
                      } else {
                        setAdjustForm({
                          ...adjustForm,
                          qtyPcs: (current + add).toString(),
                        });
                      }
                    }}
                    className="px-3 py-1 text-xs bg-brand-100 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 rounded hover:bg-brand-200 dark:hover:bg-brand-900/50 transition-colors"
                  >
                    +{selectedProduct.unitType === "KG" ? "1 kg" : "10 pcs"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const current =
                        selectedProduct.unitType === "KG"
                          ? parseFloat(adjustForm.qtyKg) || 0
                          : parseFloat(adjustForm.qtyPcs) || 0;
                      const add = selectedProduct.unitType === "KG" ? 5 : 50;
                      if (selectedProduct.unitType === "KG") {
                        setAdjustForm({
                          ...adjustForm,
                          qtyKg: (current + add).toString(),
                        });
                      } else {
                        setAdjustForm({
                          ...adjustForm,
                          qtyPcs: (current + add).toString(),
                        });
                      }
                    }}
                    className="px-3 py-1 text-xs bg-brand-100 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 rounded hover:bg-brand-200 dark:hover:bg-brand-900/50 transition-colors"
                  >
                    +{selectedProduct.unitType === "KG" ? "5 kg" : "50 pcs"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const current =
                        selectedProduct.unitType === "KG"
                          ? parseFloat(adjustForm.qtyKg) || 0
                          : parseFloat(adjustForm.qtyPcs) || 0;
                      const subtract =
                        selectedProduct.unitType === "KG" ? 1 : 10;
                      if (selectedProduct.unitType === "KG") {
                        setAdjustForm({
                          ...adjustForm,
                          qtyKg: (current - subtract).toString(),
                        });
                      } else {
                        setAdjustForm({
                          ...adjustForm,
                          qtyPcs: (current - subtract).toString(),
                        });
                      }
                    }}
                    className="px-3 py-1 text-xs bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors"
                  >
                    -{selectedProduct.unitType === "KG" ? "1 kg" : "10 pcs"}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Reason
                </label>
                <select
                  value={adjustForm.reason}
                  onChange={(e) =>
                    setAdjustForm({ ...adjustForm, reason: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="ADJUSTMENT">Manual Adjustment</option>
                  <option value="CORRECTION">Correction</option>
                  <option value="DAMAGE">Damage</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>
              <div className="flex gap-2 mt-6">
                <button
                  onClick={() => {
                    setShowAdjustModal(false);
                    setSelectedProduct(null);
                    setAdjustForm({
                      qtyKg: "",
                      qtyPcs: "",
                      reason: "ADJUSTMENT",
                    });
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAdjust}
                  className="flex-1 px-4 py-2 bg-brand-500 text-white rounded hover:bg-brand-600 transition-colors"
                >
                  Adjust Inventory
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {showAddProductModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-panel-strong rounded-2xl p-4 sm:p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 dark:text-white">
              Add New Product
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Name *
                </label>
                <input
                  type="text"
                  value={addProductForm.name}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      name: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="Example: Whole Chicken"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Category *
                </label>
                <select
                  value={addProductForm.categoryId}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      categoryId: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="">Select category</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  SKU *
                </label>
                <input
                  type="text"
                  data-skip-global-barcode="true"
                  value={addProductForm.sku}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      sku: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="Type or scan barcode"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Defaults when you open this form; edit or scan to set.
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  PLU *
                </label>
                <input
                  type="text"
                  data-skip-global-barcode="true"
                  value={addProductForm.plu}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      plu: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="Type or scan barcode"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Often same as SKU for retail barcodes.
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Unit Type *
                </label>
                <select
                  value={addProductForm.unitType}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      unitType: e.target.value as "KG" | "PCS",
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="KG">KG</option>
                  <option value="PCS">PCS</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Tax Rate (%)
                </label>
                <input
                  type="number"
                  value={addProductForm.taxRate}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      taxRate: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="0"
                  min="0"
                  step="0.01"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Price per unit *
                </label>
                <input
                  type="number"
                  value={addProductForm.pricePerUnit}
                  onChange={(e) =>
                    setAddProductForm({
                      ...addProductForm,
                      pricePerUnit: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Product Image
                </label>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      Upload from local machine:
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAddProductImageFileChange}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm dark:bg-gray-700 dark:text-white"
                    />
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    OR
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      Enter image URL:
                    </label>
                    <input
                      type="url"
                      value={addProductForm.imageUrl}
                      onChange={(e) => {
                        setAddProductForm({
                          ...addProductForm,
                          imageUrl: e.target.value,
                          imageFile: null,
                        });
                        setAddProductImagePreview(e.target.value || null);
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                  {addProductImagePreview && (
                    <div className="mt-2">
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                        Preview:
                      </p>
                      <img
                        src={addProductImagePreview}
                        alt="Preview"
                        className="w-32 h-32 object-cover rounded border border-gray-300 dark:border-gray-600"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = "none";
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-3">
              After creating the product, you can use the "Adjust" button in the
              inventory table to add opening stock.
            </p>
            <div className="flex gap-2 mt-6">
              <button
                onClick={() => {
                  setShowAddProductModal(false);
                  resetAddProductForm();
                }}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white transition-colors"
                disabled={addProductLoading}
              >
                Cancel
              </button>
              <button
                onClick={handleCreateProduct}
                className="flex-1 px-4 py-2 bg-brand-500 text-white rounded hover:bg-brand-600 disabled:opacity-60 transition-colors"
                disabled={addProductLoading}
              >
                {addProductLoading ? "Creating..." : "Create Product"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {showEditModal && editingProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-panel-strong rounded-2xl p-4 sm:p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-scale-in">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 dark:text-white">
              Edit Product
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Name *
                </label>
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(e) =>
                    setEditForm({ ...editForm, name: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="Product name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Category *
                </label>
                <select
                  value={editForm.categoryId}
                  onChange={(e) =>
                    setEditForm({ ...editForm, categoryId: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="">Select category</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  SKU *
                </label>
                <input
                  type="text"
                  value={editForm.sku}
                  onChange={(e) =>
                    setEditForm({ ...editForm, sku: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="Unique code"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  PLU *
                </label>
                <input
                  type="text"
                  value={editForm.plu}
                  onChange={(e) =>
                    setEditForm({ ...editForm, plu: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="Price look-up code"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Unit Type *
                </label>
                <select
                  value={editForm.unitType}
                  onChange={(e) =>
                    setEditForm({
                      ...editForm,
                      unitType: e.target.value as "KG" | "PCS",
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="KG">KG</option>
                  <option value="PCS">PCS</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Tax Rate (%)
                </label>
                <input
                  type="number"
                  value={editForm.taxRate}
                  onChange={(e) =>
                    setEditForm({ ...editForm, taxRate: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="0"
                  min="0"
                  step="0.01"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Price per unit *
                </label>
                <input
                  type="number"
                  value={editForm.pricePerUnit}
                  onChange={(e) =>
                    setEditForm({ ...editForm, pricePerUnit: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Product Image
                </label>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      Upload from local machine:
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFileChange}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm dark:bg-gray-700 dark:text-white"
                    />
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    OR
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      Enter image URL:
                    </label>
                    <input
                      type="url"
                      value={editForm.imageUrl}
                      onChange={(e) => {
                        setEditForm({
                          ...editForm,
                          imageUrl: e.target.value,
                          imageFile: null,
                        });
                        setImagePreview(e.target.value || null);
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                  {imagePreview && (
                    <div className="mt-2">
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                        Preview:
                      </p>
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-32 h-32 object-cover rounded border border-gray-300 dark:border-gray-600"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = "none";
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setEditingProduct(null);
                  setEditForm({
                    name: "",
                    sku: "",
                    plu: "",
                    categoryId: "",
                    unitType: "KG",
                    taxRate: "0",
                    pricePerUnit: "",
                    imageUrl: "",
                    imageFile: null,
                  });
                  setImagePreview(null);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white transition-colors"
                disabled={editLoading}
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateProduct}
                className="flex-1 px-4 py-2 bg-brand-500 text-white rounded hover:bg-brand-600 disabled:opacity-60 transition-colors"
                disabled={editLoading}
              >
                {editLoading ? "Updating..." : "Update Product"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Stock Modal */}
      {showEditStockModal && editStockProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-panel-strong rounded-2xl p-4 sm:p-6 w-full max-w-md max-h-[90vh] overflow-y-auto animate-scale-in">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 dark:text-white">
              Edit Stock
            </h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                  Product:{" "}
                  <strong className="dark:text-white">
                    {editStockProduct.productName}
                  </strong>
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  Current Stock:{" "}
                  {editStockProduct.unitType === "KG"
                    ? `${editStockProduct.currentQtyKg.toFixed(2)} kg`
                    : `${editStockProduct.currentQtyPcs} pcs`}
                </p>
                {showOwnerLedgerPicker && (
                  <p className="text-xs text-amber-700 dark:text-amber-300 mb-3">
                    The table shows combined stock across locations. The new
                    quantity you set applies only to the store selected below.
                  </p>
                )}
                {showOwnerLedgerPicker && user?.storeId && (
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Apply to store
                    </label>
                    <select
                      value={ownerOpsLedgerStoreId || user.storeId}
                      onChange={(e) =>
                        setOwnerOpsLedgerStoreId(e.target.value)
                      }
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                    >
                      <option value={user.storeId}>
                        {user.store.name} (HQ)
                      </option>
                      {ownerFranchises.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  New Stock{" "}
                  {editStockProduct.unitType === "KG" ? "(kg)" : "(pcs)"} *
                </label>
                <input
                  type="number"
                  value={
                    editStockProduct.unitType === "KG"
                      ? editStockForm.qtyKg
                      : editStockForm.qtyPcs
                  }
                  onChange={(e) => {
                    if (editStockProduct.unitType === "KG") {
                      setEditStockForm({
                        ...editStockForm,
                        qtyKg: e.target.value,
                      });
                    } else {
                      setEditStockForm({
                        ...editStockForm,
                        qtyPcs: e.target.value,
                      });
                    }
                  }}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                  placeholder={
                    editStockProduct.unitType === "KG" ? "0.00" : "0"
                  }
                  step={editStockProduct.unitType === "KG" ? "0.01" : "1"}
                  min="0"
                  required
                  autoFocus
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Enter the exact stock quantity you want to set
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Reason
                </label>
                <select
                  value={editStockForm.reason}
                  onChange={(e) =>
                    setEditStockForm({
                      ...editStockForm,
                      reason: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="CORRECTION">Correction</option>
                  <option value="ADJUSTMENT">Manual Adjustment</option>
                  <option value="DAMAGE">Damage</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>
              <div className="flex gap-2 mt-6">
                <button
                  onClick={() => {
                    setShowEditStockModal(false);
                    setEditStockProduct(null);
                    setEditStockForm({
                      qtyKg: "",
                      qtyPcs: "",
                      reason: "CORRECTION",
                    });
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleEditStock}
                  className="flex-1 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
                >
                  Update Stock
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && productToDelete && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-3 sm:p-4 safe-top safe-bottom">
          <div className="glass-panel-strong rounded-2xl p-4 sm:p-6 w-full max-w-md max-h-[90vh] overflow-y-auto animate-scale-in">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 dark:text-white text-red-600 dark:text-red-400">
              Delete Product
            </h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                  Are you sure you want to delete this product? This action
                  cannot be undone.
                </p>
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 mt-3">
                  <p className="font-semibold text-base dark:text-white mb-1">
                    {productToDelete.productName}
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    SKU: {productToDelete.sku} | PLU: {productToDelete.plu}
                  </p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowDeleteModal(false);
                    setProductToDelete(null);
                  }}
                  className="flex-1 px-4 py-3 text-base border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white transition-colors touch-target"
                  disabled={deleteLoading}
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteProduct}
                  className="flex-1 px-4 py-3 text-base bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-60 transition-colors touch-target font-semibold"
                  disabled={deleteLoading}
                >
                  {deleteLoading ? "Deleting..." : "Delete Product"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
