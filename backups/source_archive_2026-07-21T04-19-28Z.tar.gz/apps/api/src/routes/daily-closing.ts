// @ts-nocheck
import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '@azela-pos/db';
import { z } from 'zod';
import {
  salesInStoreDayWhere,
  storeDayBoundsFromYmd,
  closingDateStorageKey,
  tallyPaymentsFromSales,
  tallyToClosingFields,
  resolveStoreDateRange,
} from '@azela-pos/shared';
import { requireRole } from '../utils/auth.js';
import { getUser } from '../utils/auth.js';

const dailyClosingSchema = z.object({
  closingDate: z.string(),
  shiftId: z.string().optional(),
  openingCash: z.number().min(0),
  cashReceived: z.number().min(0),
  closingCash: z.number().min(0),
  notes: z.string().optional(),
});

// Enhanced validation function
function validateDailyClosing(data: {
  openingCash: number;
  cashReceived: number;
  closingCash: number;
  cashSales: number;
  totalRevenue: number;
  totalWastageKg: number;
  totalWeightSoldKg: number;
}) {
  const warnings: string[] = [];
  const errors: string[] = [];

  // Critical validations (will block save)
  if (data.cashReceived < 0 || data.closingCash < 0 || data.openingCash < 0) {
    errors.push('Cash amounts cannot be negative');
  }

  // Calculate cash difference
  const expectedClosing = data.openingCash + data.cashReceived;
  const cashDifference = Math.abs(data.closingCash - expectedClosing);
  const cashVariancePercent = expectedClosing > 0 ? (cashDifference / expectedClosing) * 100 : 0;

  // Warning validations
  if (cashVariancePercent > 5) {
    warnings.push(`High cash variance: ${cashVariancePercent.toFixed(1)}% (₹${cashDifference.toFixed(2)})`);
  }

  if (data.cashSales > data.totalRevenue * 0.9) {
    warnings.push('High cash sales percentage (>90% of total revenue)');
  }

  if (data.totalWastageKg > data.totalWeightSoldKg * 0.1 && data.totalWeightSoldKg > 0) {
    const wastagePercent = ((data.totalWastageKg / data.totalWeightSoldKg) * 100).toFixed(1);
    warnings.push(`High wastage detected: ${wastagePercent}% of sales`);
  }

  if (data.totalRevenue === 0) {
    warnings.push('No revenue recorded for this day');
  }

  // Minimum opening cash requirement
  if (data.openingCash < 1000 && data.cashSales > 0) {
    warnings.push('Low opening cash (recommended: ₹1000+)');
  }

  // Check cash reconciliation
  if (Math.abs(data.cashReceived - data.cashSales) > 100) {
    warnings.push('Cash received differs from cash sales by more than ₹100');
  }

  return { errors, warnings, isValid: errors.length === 0 };
}

export async function dailyClosingRoutes(fastify: FastifyInstance) {
  // Create daily closing
  fastify.post(
    '/daily-closing',
    { preHandler: [fastify.authenticate] },
    async (request: any, reply: FastifyReply) => {
      try {
        const storeId = (getUser(request) as any).storeId;
        const userId = (getUser(request) as any).userId;
        const { closingDate, openingCash, cashReceived, closingCash, notes, shiftId } = (request.body as any);

        // Store calendar day (IST) — matches when staff actually traded.
        const closingDateStr = closingDate.split('T')[0]; // YYYY-MM-DD
        const closingDateObj = closingDateStorageKey(closingDateStr);
        const { gte: dayStart, lte: dayEnd } = storeDayBoundsFromYmd(closingDateStr);

        // Check if closing already exists for this date
        const existing = await prisma.dailyClosing.findUnique({
          where: {
            storeId_closingDate: {
              storeId,
              closingDate: closingDateObj,
            },
          },
        });

        if (existing && existing.isFinalized) {
          reply.code(400).send({ error: 'Daily closing already finalized for this date' });
          return;
        }

        // Get all PAID sales for the store calendar day (IST).
        const sales = await prisma.sale.findMany({
          where: salesInStoreDayWhere(storeId, closingDateStr, 'PAID'),
          include: {
            items: {
              include: {
                product: true,
              },
            },
            payments: true,
          },
        });

        // Calculate totals - Round to 3 decimal places for money to avoid calculation mismatches
        const totalSales = sales.length;
        const totalRevenue = Math.round(sales.reduce((sum: any, s: any) => sum + s.grandTotal, 0) * 1000) / 1000;
        const totalDiscounts = Math.round(sales.reduce((sum: any, s: any) => sum + s.discountTotal, 0) * 1000) / 1000;
        const totalTax = Math.round(sales.reduce((sum: any, s: any) => sum + s.taxTotal, 0) * 1000) / 1000;

        const paymentTotals = tallyPaymentsFromSales(sales);
        const { cashSales, cardSales, upiSales } = tallyToClosingFields(paymentTotals);

        // Auto-set cashReceived from cashSales (cash revenue)
        // If cashReceived is provided, use it; otherwise use cashSales
        const finalCashReceived = cashReceived !== undefined && cashReceived !== null ? cashReceived : cashSales;

        // Calculate total weight sold - Round to 2 decimal places for KG
        const totalWeightSoldKg = Math.round(sales.reduce((sum: any, s: any) => {
          return (
            sum +
            s.items.reduce((itemSum, item) => {
              if (item.product.unitType === 'KG') {
                return itemSum + (item.qtyKg || 0);
              }
              return itemSum;
            }, 0)
          );
        }, 0) * 100) / 100;

        // Get wastage for the day
        const wastageLedgers = await prisma.inventoryLedger.findMany({
          where: {
            storeId,
            reason: 'WASTAGE',
            createdAt: {
              gte: dayStart,
              lte: dayEnd,
            },
          },
        });

        const totalWastageKg = Math.round(wastageLedgers.reduce(
          (sum, ledger) => Math.round((sum + (ledger.qtyKg || 0) + (ledger.qtyPcs || 0)) * 100) / 100,
          0
        ) * 100) / 100;

        // Enhanced validation before saving
        const validation = validateDailyClosing({
          openingCash,
          cashReceived: finalCashReceived,
          closingCash,
          cashSales,
          totalRevenue,
          totalWastageKg,
          totalWeightSoldKg,
        });

        if (!validation.isValid) {
          reply.code(400).send({ 
            error: 'Validation failed', 
            errors: validation.errors 
          });
          return;
        }

        // Get closing stock for all products
        // First get the owner store ID
        const store = await prisma.store.findUnique({
          where: { id: storeId },
          select: { id: true, name: true, type: true, parentOwnerStoreId: true }
        });
        
        const ownerStoreId = store?.type === 'FRANCHISE' ? store.parentOwnerStoreId : storeId;
        
        const products = await prisma.product.findMany({
          where: {
            ownerStoreId: ownerStoreId || storeId,
            isActive: true,
          },
        });

        const closingStock: Record<string, { qtyKg: number; qtyPcs: number }> = {};

        for (const product of products) {
          const ledgers = await prisma.inventoryLedger.findMany({
            where: {
              storeId,
              productId: product.id,
            },
            orderBy: { createdAt: 'asc' },
          });

          let qtyKg = 0;
          let qtyPcs = 0;

          for (const ledger of ledgers) {
            if (ledger.type === 'IN') {
              qtyKg += ledger.qtyKg || 0;
              qtyPcs += ledger.qtyPcs || 0;
            } else {
              qtyKg -= ledger.qtyKg || 0;
              qtyPcs -= ledger.qtyPcs || 0;
            }
          }

          // Round to 2 decimal places for KG, integer for PCS
          closingStock[product.id] = {
            qtyKg: Math.round((Math.max(0, qtyKg)) * 100) / 100,
            qtyPcs: Math.max(0, Math.round(qtyPcs)),
          };
        }

        // Calculate cash difference - Round to 3 decimal places
        // Expected cash = opening cash + cash received (which is auto-set from cash sales)
        const cashExpected = Math.round((openingCash + finalCashReceived) * 1000) / 1000;
        const cashDifference = Math.round((closingCash - cashExpected) * 1000) / 1000;

        // Create or update daily closing
        const dailyClosing = await prisma.dailyClosing.upsert({
          where: {
            storeId_closingDate: {
              storeId,
              closingDate: closingDateObj,
            },
          },
          update: {
            shiftId: shiftId || null,
            openingCash,
            cashSales,
            cardSales,
            upiSales,
            cashReceived: finalCashReceived,
            cashExpected,
            cashDifference,
            closingCash,
            totalWeightSoldKg,
            totalWastageKg,
            closingStockJson: closingStock,
            totalSales,
            totalRevenue,
            totalDiscounts,
            totalTax,
            notes: notes || null,
          },
          create: {
            storeId,
            shiftId: shiftId || null,
            closingDate: closingDateObj,
            closedBy: userId,
            openingCash,
            cashSales,
            cardSales,
            upiSales,
            cashReceived: finalCashReceived,
            cashExpected,
            cashDifference,
            closingCash,
            totalWeightSoldKg,
            totalWastageKg,
            closingStockJson: closingStock,
            totalSales,
            totalRevenue,
            totalDiscounts,
            totalTax,
            notes: notes || null,
          },
          include: {
            closer: {
              select: { id: true, name: true },
            },
            shift: {
              select: { id: true, openedAt: true, closedAt: true },
            },
          },
        });

        // Create audit log
        await prisma.auditLog.create({
          data: {
            storeId,
            actorUserId: userId,
            action: 'DAILY_CLOSING_CREATED',
            entityType: 'DailyClosing',
            entityId: dailyClosing.id,
            metaJson: {
              closingDate: closingDateObj.toISOString(),
              totalSales,
              totalRevenue,
              cashDifference,
            },
          },
        });

        return dailyClosing;
      } catch (error: any) {
        console.error('Failed to create daily closing:', error);
        reply.code(500).send({ error: 'Failed to create daily closing' });
      }
    }
  );

  // Finalize daily closing
  fastify.patch(
    '/daily-closing/:id/finalize',
    { preHandler: [fastify.authenticate, requireRole('MANAGER', 'OWNER')] },
    async (request: any, reply: FastifyReply) => {
      try {
        const storeId = (getUser(request) as any).storeId;
        const userId = (getUser(request) as any).userId;
        const { id } = request.params as { id: string };

        if (!id) {
          reply.code(400).send({ error: 'Daily closing ID is required' });
          return;
        }

        const closing = await prisma.dailyClosing.findUnique({
          where: { id },
        });

        if (!closing || closing.storeId !== storeId) {
          reply.code(404).send({ error: 'Daily closing not found' });
          return;
        }

        if (closing.isFinalized) {
          reply.code(400).send({ error: 'Daily closing already finalized' });
          return;
        }

        const updated = await prisma.dailyClosing.update({
          where: { id },
          data: {
            isFinalized: true,
            finalizedAt: new Date(),
          },
        });

        // Create audit log
        await prisma.auditLog.create({
          data: {
            storeId,
            actorUserId: userId,
            action: 'DAILY_CLOSING_FINALIZED',
            entityType: 'DailyClosing',
            entityId: id,
          },
        });

        return updated;
      } catch (error: any) {
        console.error('Failed to finalize daily closing:', error);
        reply.code(500).send({ error: 'Failed to finalize daily closing' });
      }
    }
  );

  // Get daily closing by date
  fastify.get(
    '/daily-closing/:date',
    { preHandler: [fastify.authenticate] },
    async (request: any, reply: FastifyReply) => {
      try {
        const storeId = (getUser(request) as any).storeId;
        let { date } = request.params as any;

        // Decode URL-encoded date if needed
        date = decodeURIComponent(date);

        // Handle both YYYY-MM-DD and ISO date strings
        const closingDateStr = date.split('T')[0]; // Get YYYY-MM-DD
        const closingDate = closingDateStorageKey(closingDateStr);
        
        // Validate date
        if (isNaN(closingDate.getTime())) {
          reply.code(400).send({ error: 'Invalid date format. Expected YYYY-MM-DD' });
          return;
        }

        // Try to find closing with exact date match
        let closing = await prisma.dailyClosing.findUnique({
          where: {
            storeId_closingDate: {
              storeId,
              closingDate,
            },
          },
          include: {
            closer: {
              select: { id: true, name: true },
            },
            shift: {
              select: { id: true, openedAt: true, closedAt: true },
            },
          },
        });

        // If not found with exact match, try finding by date range (in case of timezone issues)
        if (!closing) {
          const closingDateStart = closingDateStorageKey(closingDateStr);
          const { lte: closingDateEnd } = storeDayBoundsFromYmd(closingDateStr);
          
          closing = await prisma.dailyClosing.findFirst({
            where: {
              storeId,
              closingDate: {
                gte: closingDateStart,
                lte: closingDateEnd,
              },
            },
            include: {
              closer: {
                select: { id: true, name: true },
              },
              shift: {
                select: { id: true, openedAt: true, closedAt: true },
              },
            },
          });
        }

        if (!closing) {
          reply.code(404).send({ error: 'Daily closing not found for this date' });
          return;
        }

        // Refresh live totals for open closings so cash/UPI stay current during the day.
        if (!closing.isFinalized) {
          const sales = await prisma.sale.findMany({
            where: salesInStoreDayWhere(storeId, closingDateStr, 'PAID'),
            include: { payments: true },
          });
          const paymentTotals = tallyPaymentsFromSales(sales);
          const { cashSales, cardSales, upiSales } = tallyToClosingFields(paymentTotals);
          const totalRevenue =
            Math.round(sales.reduce((sum: number, s: any) => sum + (s.grandTotal || 0), 0) * 1000) /
            1000;
          return {
            ...closing,
            totalSales: sales.length,
            totalRevenue,
            totalDiscounts:
              Math.round(sales.reduce((sum: number, s: any) => sum + (s.discountTotal || 0), 0) * 1000) /
              1000,
            totalTax:
              Math.round(sales.reduce((sum: number, s: any) => sum + (s.taxTotal || 0), 0) * 1000) /
              1000,
            cashSales,
            cardSales,
            upiSales,
          };
        }

        return closing;
      } catch (error: any) {
        console.error('Failed to load daily closing:', error);
        console.error('Date parameter:', request.params?.date);
        reply.code(500).send({ error: 'Failed to load daily closing', details: error.message });
      }
    }
  );

  // Get daily closing history
  fastify.get(
    '/daily-closing',
    { preHandler: [fastify.authenticate] },
    async (request: any, reply: FastifyReply) => {
      try {
        const storeId = (getUser(request) as any).storeId;
        const { startDate, endDate } = (request.query as any);

        const where: any = { storeId };

        if (startDate && endDate) {
          const { gte, lte } = resolveStoreDateRange(startDate, endDate);
          where.closingDate = { gte, lte };
        }

        const closings = await prisma.dailyClosing.findMany({
          where,
          include: {
            closer: {
              select: { id: true, name: true },
            },
          },
          orderBy: { closingDate: 'desc' },
          take: 30,
        });

        return closings;
      } catch (error: any) {
        console.error('Failed to load daily closing history:', error);
        reply.code(500).send({ error: 'Failed to load daily closing history' });
      }
    }
  );
}

