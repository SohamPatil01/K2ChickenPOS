import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', '"SF Pro Display"', 'system-ui', 'sans-serif'],
      },
      colors: {
        // Primary Brand (Orange Spectrum)
        brand: {
          900: '#7A2E00',
          800: '#9A3E00',
          700: '#C04A00',
          600: '#E65C00',
          500: '#FF6A00', // PRIMARY BRAND
          400: '#FF8A3D',
          300: '#FFB37A',
          200: '#FFD5B3',
          100: '#FFF0E6',
        },
        // Legacy primary mapping (for backward compatibility)
        primary: {
          900: '#7A2E00',
          800: '#9A3E00',
          700: '#C04A00',
          600: '#E65C00',
          500: '#FF6A00',
          400: '#FF8A3D',
          300: '#FFB37A',
          200: '#FFD5B3',
          100: '#FFF0E6',
        },
        // Accent Colors
        accent: {
          success: '#16A34A',
          warning: '#FACC15',
          danger: '#DC2626',
          info: '#2563EB',
        },
        // Neutrals
        neutral: {
          black: '#0F0F0F',
          gray900: '#181818',
          gray700: '#2A2A2A',
          gray500: '#6B7280',
          gray300: '#D1D5DB',
          gray100: '#F5F5F5',
          white: '#FFFFFF',
        },
      },
      borderRadius: {
        xl2: '16px',
      },
      boxShadow: {
        card: '0px 6px 20px rgba(0, 0, 0, 0.08)',
        orangeGlow: '0px 10px 30px rgba(255, 106, 0, 0.4)',
        inputFocus: '0px 0px 0px 3px rgba(255, 106, 0, 0.35)',
        inputError: '0px 0px 0px 2px rgba(220, 38, 38, 0.3)',
        buttonHover: '0px 8px 24px rgba(255, 106, 0, 0.35)',
      },
      transitionDuration: {
        standard: '180ms',
      },
      transitionTimingFunction: {
        standard: 'ease-out',
      },
    },
  },
  plugins: [],
};

export default config;

